package com.example.healthcare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Credentials;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

@SuppressWarnings("SyntaxError")
public class register extends AppCompatActivity {

    public static Credentials credentials;
    private EditText etname;
    private EditText etregpass;
    private EditText etEmail;
    private Button btnRegis;
    private Button btnback;
    private FirebaseAuth FirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        setupUIViews();
        FirebaseAuth = com.google.firebase.auth.FirebaseAuth.getInstance();
        btnRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) ;

                String user_email = etEmail.getText().toString().trim();
                String Password = etregpass.getText().toString().trim();

                FirebaseAuth.createUserWithEmailAndPassword(user_email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(register.this, "sucessful", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(register.this, "failed", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent (register.this, MainActivity.class));
            }
        });
    }

    private void setupUIViews() {
        etname = findViewById(R.id.etname);
        etregpass = findViewById(R.id.etregpass);
        etEmail = findViewById(R.id.etregpass);
        btnback = findViewById(R.id.btnReg);
        btnRegis = findViewById(R.id.btnRegis);
    }

    private boolean validate() {
        boolean result = false;
        String name = etname.getText().toString();
        String password = etregpass.getText().toString();
        String Email = etEmail.getText().toString();
        if (name.isEmpty() && password.isEmpty() && Email.isEmpty()) {
            Toast.makeText(this, "please enter all the details", Toast.LENGTH_LONG).show();
        } else {
            result = true;
        }
        return result;
    }

}


