package com.example.myapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Homepage extends AppCompatActivity {
    //all the Buttons//
    public Button mentalhealth;
    public Button Medication;
    public Button TreatmentRecord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        mentalhealth=findViewById(R.id.btnMH);
        Medication=findViewById(R.id.btnMedication);
        TreatmentRecord=findViewById(R.id.btnTreatmentRecord);

        //where everthing links up and makes sense//

        TreatmentRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentT = new Intent(Homepage.this, YourTreatmentRecord.class);
                startActivity(intentT);
            }
        });

        Medication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentM = new Intent(Homepage.this, MedicationandTreatment.class);
                startActivity(intentM);
            }
        });

        mentalhealth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Homepage.this, MentalHealth.class);
                startActivity(intent);
            }
        });


    }
}

//thats about it tbh//