package com.example.bvp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;




public class MainActivity extends AppCompatActivity {
    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    private Button UserRegistration;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private Button Forgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Name = (EditText)findViewById(R.id.ETEmail);
        Password = (EditText)findViewById(R.id.ETPassword);
        Info = (TextView)findViewById(R.id.tvinfo);
        Login = (Button)findViewById(R.id.btnLogIn);
        Forgot = (Button) findViewById(R.id.btnForgot);
        Info.setText("Number of attempts remaining:5");
        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);
        FirebaseUser user  =  firebaseAuth.getCurrentUser();
        if(user != null) {
            finish();
            startActivity(new Intent(MainActivity.this, com.example.BVP.Legal.class));
        }
        Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, com.example.myapplication.ForgotPassword.class));
            }
        });
        UserRegistration = (Button)findViewById(R.id.btnRegister);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Name.getText().toString(), Password.getText().toString());
            }
        });
        UserRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, com.example.BVP.Register.class));

            }
        });

    }
    private void validate(String userName, String userPassword) {
        progressDialog.setMessage("Checking :)");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(userName, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    progressDialog.dismiss();
                    //Toast.makeText(MainActivity.this,"login Succesful", Toast.LENGTH_SHORT).show();
                    checkEmailVerifaction();
                }else{
                    Toast.makeText(MainActivity.this,"login Failed", Toast.LENGTH_SHORT).show();
                    counter--;
                    Info.setText("Number of Attmpts remaining:" + counter);
                    progressDialog.dismiss();
                    if(counter == 0){
                        Login.setEnabled(false);
                    }
                }
            }
        });

    }

    private void checkEmailVerifaction(){
        FirebaseUser firebaseUser = firebaseAuth.getInstance().getCurrentUser();
        Boolean EmailFlag = firebaseUser.isEmailVerified();
        if(EmailFlag) {
            finish();
            startActivity(new Intent(MainActivity.this, com.example.BVP.Legal.class));
        }else{
            Toast.makeText(this, "Verify your email please", Toast.LENGTH_LONG).show();
            firebaseAuth.signOut();
        }

    }

}








