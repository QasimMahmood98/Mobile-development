package com.example.bvp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class registration extends AppCompatActivity {
    private Button btnSubmit;
    private Button btnExisiting;
    private EditText etemail;
    private EditText etpass;
    private EditText etname;
    private EditText etAddress;
    private EditText etphone;
    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setupUIviews();
        //firebase
        firebaseAuth = firebaseAuth.getInstance();
        //registrationbutton
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate());
                //uploading data to database
                String username = etname.getText().toString().trim();
                String Password = etpass.getText().toString().trim();
                String Email = etemail.getText().toString().trim();
                firebaseAuth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(registration.this, "success",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(registration.this, MainActivity.class));
                        } else {
                            Toast.makeText(registration.this, "fail",Toast.LENGTH_LONG).show();
                        }

                    }
                });
            }
        });
        //exisiting User
        btnExisiting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent(registration.this, MainActivity.class));
            }
        });
    }

    private void setupUIviews() {
        btnSubmit =(Button)findViewById(R.id.btnSubmit);
        btnExisiting=(Button)findViewById(R.id.btnExisiting);
        etAddress = (EditText)findViewById(R.id.etAddress);
        etemail = (EditText)findViewById(R.id.etemail);
        etphone = (EditText)findViewById(R.id.etphone);
        etpass = (EditText)findViewById(R.id.etpass);
        etname = (EditText)findViewById(R.id.etname);
    }

    //validation
    private Boolean validate() {
        Boolean results = false;
        String name = etname.getText().toString();
        String Password = etpass.getText().toString();
        String Email = etemail.getText().toString();

        if(name.isEmpty() || Password.isEmpty() || Email.isEmpty()){
            Toast.makeText(this,"Please Enter all the details", Toast.LENGTH_SHORT).show();
        }else{
            results = true;
        }
        return results;
    }

}