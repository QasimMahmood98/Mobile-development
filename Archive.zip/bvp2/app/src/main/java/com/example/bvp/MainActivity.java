package com.example.bvp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnLogin;
    private Button btnregister;
    private Button btnForgot;
    private EditText etpassword;
    private EditText etname;
    private TextView tvattempts;
    private int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = (Button) findViewById(R.id.btnlogin);
        btnForgot = (Button) findViewById(R.id.btnforgot);
        btnregister = (Button) findViewById(R.id.btnregister);
        etname = (EditText) findViewById(R.id.etname);
        etpassword = (EditText) findViewById(R.id.etpassword);
        tvattempts = (TextView) findViewById(R.id.tvattempts);
        //btnlogin
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validation(etname.getText().toString(), etpassword.getText().toString());
            }
        });
    }

    //validation
    private void validation(String username, String password) {
        if ((username.equals("admin")) && (password.equals("12345"))) {
            Intent intent = new Intent(MainActivity.this, mainpage.class);

            startActivity(intent);
        } else {
            counter--;
            tvattempts.setText("number of attempts:" + String.valueOf(counter));
            if (counter == 0) {
                btnLogin.setEnabled(false);

            }
        }
        //register
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, registration.class));
            }
        });
    }
}