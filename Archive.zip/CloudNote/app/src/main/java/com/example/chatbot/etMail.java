package com.example.chatbot;

public class etMail {
}
